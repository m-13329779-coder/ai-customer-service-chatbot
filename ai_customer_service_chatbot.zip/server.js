require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const KNOWLEDGE_PATH = path.join(__dirname, "knowledge.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function getKnowledge() {
  try {
    return JSON.parse(fs.readFileSync(KNOWLEDGE_PATH, "utf8"));
  } catch (e) {
    return { businessName: "Nova Store", faqs: [], policies: [] };
  }
}

function localFallback(message, knowledge) {
  const q = String(message || "").toLowerCase();
  const faqs = knowledge.faqs || [];
  const match = faqs.find(item =>
    (item.keywords || []).some(k => q.includes(k.toLowerCase()))
  );
  if (match) return match.answer;
  if (/\b(human|person|agent|staff|complaint|complain)\b/.test(q)) {
    return "I can flag this for a team member. This starter project does not send a real notification yet; connect an approved support channel before using it with customers.";
  }
  return "I’m not certain based on the business information I have. Please contact the business team so they can confirm. I won’t guess about prices, stock, refunds, or order status.";
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
  if (!message) return res.status(400).json({ error: "Please enter a message." });
  if (message.length > 2000) return res.status(400).json({ error: "Please keep messages under 2,000 characters." });

  const knowledge = getKnowledge();
  const fallback = () => res.json({
    reply: localFallback(message, knowledge),
    mode: "demo",
    handoffSuggested: /\b(human|person|agent|staff|complaint|complain)\b/i.test(message)
  });

  if (!process.env.OPENAI_API_KEY) return fallback();

  try {
    const instructions = [
      `You are the friendly customer support assistant for ${knowledge.businessName || "this business"}.`,
      "Answer using only the verified business information supplied below and the conversation context.",
      "Never invent prices, inventory, delivery status, opening hours, refund eligibility, or policy details.",
      "If the information is missing or uncertain, say so clearly and recommend contacting a human team member.",
      "Do not request passwords, full payment card details, or sensitive identity information.",
      "Do not claim to have contacted staff, changed an order, issued a refund, or checked a live system unless a connected tool actually did so.",
      "Keep replies concise, kind, and useful. If a customer asks for a human, acknowledge that request.",
      "Business knowledge (JSON):",
      JSON.stringify(knowledge, null, 2)
    ].join("\n\n");

    const input = [
      ...history.filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
        .map(m => ({ role: m.role, content: m.content.slice(0, 2000) })),
      { role: "user", content: message }
    ];

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions,
        input,
        max_output_tokens: 300
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI API error:", response.status, errorText.slice(0, 500));
      return res.status(502).json({ error: "The AI service could not answer right now. Please try again later." });
    }

    const data = await response.json();
    const reply = data.output_text ||
      (data.output || []).flatMap(o => o.content || []).map(c => c.text || "").join("\n").trim();

    if (!reply) return res.status(502).json({ error: "The AI service returned an empty answer. Please try again." });
    res.json({
      reply,
      mode: "ai",
      handoffSuggested: /\b(human|person|agent|staff|complaint|complain|speak to someone)\b/i.test(message)
    });
  } catch (err) {
    console.error("Chat error:", err.message);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

app.listen(PORT, () => {
  console.log(`Customer chatbot running at http://localhost:${PORT}`);
  console.log(`AI mode: ${process.env.OPENAI_API_KEY ? "configured" : "demo fallback mode"}`);
});
