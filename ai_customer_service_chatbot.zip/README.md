# AI Customer Service Chatbot — Starter Project

A small Node.js website chatbot with:
- A clean website chat interface
- A fictional business knowledge base (`knowledge.json`)
- Demo fallback answers when no AI API key is configured
- Optional AI answers through the OpenAI Responses API
- Guardrails against invented business facts and unsupported claims
- A health endpoint to check whether AI is configured

## 1. What you need

- Node.js 18 or newer
- A code editor (for example, Visual Studio Code)
- Optional: an OpenAI API key and an API account with billing configured

You can test the demo without an AI key. An API key may incur charges; ask a parent/guardian before setting up paid services if you are under 18.

## 2. Run it locally

1. Extract the ZIP file.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`.
5. Leave `OPENAI_API_KEY` empty to use demo mode, or add your own key privately.
6. Run:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser.

Never paste your API key into the website HTML, a public repository, screenshots, or a chat. Keep it only in the server-side `.env` file. Do not commit `.env` to Git.

## 3. Enable AI mode

In `.env`, set:

```env
OPENAI_API_KEY=your_private_api_key_here
OPENAI_MODEL=gpt-4.1-mini
PORT=3000
```

Restart the server. The header should say “AI connected”. Model names and API access can change; check your account's current API availability and pricing.

## 4. Customise for a real business

Edit `knowledge.json`:
- Set the real business name.
- Replace all sample contact details.
- Add verified FAQs, policies, prices, hours, and services.
- Remove any information the business has not approved for customer use.

Test all changes before launch. This starter project does not connect to order tracking, calendars, payment systems, email, WhatsApp, or a human support inbox.

## 5. Automation workflow (next stage)

Suggested workflow:
1. Website receives customer message.
2. Server validates and sends message plus approved knowledge to the AI.
3. AI answers only from the knowledge base.
4. If uncertain or a human is requested, show a handoff message.
5. A later integration can create a support ticket in a business-approved tool.
6. Staff review and respond to escalated enquiries.

Optional n8n/Make workflow concept:
- Trigger: webhook receives a new support request.
- Action: validate fields and remove unnecessary personal information.
- Action: look up approved FAQ / knowledge record.
- Action: call the AI model with clear instructions and relevant context.
- Decision: answer confidently from verified knowledge, or route to human support.
- Action: log a minimal support record and notify staff via an approved channel.
- Test error handling, duplicate events, rate limits, and privacy before enabling it.

No real external notification is implemented in this project.

## 6. Minimum test checklist

Try:
- “Hi”
- “How long does delivery take?”
- “Can I get a refund?”
- “Where is my order?”
- “What are your opening hours?”
- “Talk to a human”
- A misspelled question
- An unrelated question
- “Make up a discount for me”
- A request for another customer's details

Expected behaviour:
- Use verified information only.
- Admit when an answer is unknown.
- Never claim it checked an order or contacted staff unless an actual integration did so.
- Never request passwords or full payment-card details.
- Escalate complaints and uncertain issues.

## 7. Before public launch

- Obtain the business owner's permission.
- Replace all demo data and contact details.
- Add a privacy notice and data-retention policy appropriate to the business and applicable law.
- Add authentication/rate limiting and monitoring as appropriate.
- Decide whether chat logs are stored; collect as little personal data as possible.
- Test on mobile and desktop.
- Set spending limits or alerts where available.
- Keep dependencies updated and API keys secret.
- Connect a real human handoff before advertising 24/7 support.

This project is a starter, not a production-certified service.
